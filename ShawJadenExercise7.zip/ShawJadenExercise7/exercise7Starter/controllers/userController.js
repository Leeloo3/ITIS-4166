const model = require('../models/user');

// Render the new user registration form
exports.new = (req, res)=>{
    res.render('./user/new');
};

// Create a new user
exports.create = (req, res, next)=>{
    let user = new model(req.body);
    user.save()
    .then(user=> {
        req.session.user = user;
        req.flash('success', 'Registration succeeded!');
        res.redirect('/users/profile');
    })
    .catch(err=>{
        if(err.name === 'ValidationError' ) {
            req.flash('error', err.message);
            return res.redirect('/users/new');
        }
        if(err.code === 11000) {
            req.flash('error', 'Email has been used');
            return res.redirect('/users/new');
        }
        next(err);
    });
};

// Render the login form
exports.getUserLogin = (req, res, next) => {
    res.render('./user/login');
};

// Process login request
exports.login = (req, res, next)=>{
    let email = req.body.email;
    let password = req.body.password;
    
    // Get user that matches the email
    model.findOne({ email: email })
    .then(user => {
        if (!user) {
            req.flash('error', 'Wrong email address');
            res.redirect('/users/login');
        } else if (password === user.password) {
            req.session.user = user;
            req.flash('success', 'You have successfully logged in');
            res.redirect('/users/profile');
        } else {
            req.flash('error', 'Wrong password');
            res.redirect('/users/login');
        }
    })
    .catch(err => next(err));
};

// Render user profile
exports.profile = (req, res, next)=>{
    let user = req.session.user;
    if(user) {
        res.render('./user/profile', {user});
    } else {
        req.flash('error', 'Please log in first');
        res.redirect('/users/login');
    }
};

// Logout user
exports.logout = (req, res, next)=>{
    req.session.destroy(err=>{
        if(err) 
           return next(err);
        else
            res.redirect('/');  
    });
}; 