// Check if user is a guest
exports.isGuest = (req, res, next)=>{
    if(!req.session.user){
        return next();
    } else {
        res.redirect('/users/profile');
    }
};

// Check if user is authenticated
exports.isLoggedIn = (req, res, next) =>{
    if(req.session.user){
        return next();
    } else {
        res.redirect('/users/login');
    }
}; 